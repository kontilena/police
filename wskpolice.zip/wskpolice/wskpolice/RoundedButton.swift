//
//  RoundedButton.swift
//  wskpolice
//
//  Created by user on 13.09.2022.
//

import UIKit

@IBDesignable
class RoundedButton: UIButton {

    @IBInspectable var kruglayaknopka: CGFloat = 0.0 {
        didSet { self.layer.cornerRadius = kruglayaknopka }
    }

}
